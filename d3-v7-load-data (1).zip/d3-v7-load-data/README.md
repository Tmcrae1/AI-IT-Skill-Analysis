# D3 v7 load data

A Pen created on CodePen.

Original URL: [https://codepen.io/Taylor187/pen/wBJyJwO](https://codepen.io/Taylor187/pen/wBJyJwO).

